<x-default-layout>
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        
        <!--begin::Content wrapper-->
        <div class="d-flex flex-column flex-column-fluid pb-10">
            <div class="p-5 mx-5">
                <!--begin:::Tabs-->
                <ul id="myTabjustified" role="tablist" class="nav nav-custom nav-tabs nav-line-tabs nav-line-tabs-2x border-0 fs-4 fw-semibold mb-8">
                    <!--begin:::Tab item-->
                    <li class="nav-item">
                        <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                            Employee Details 
                        </h1>
                    </li>
                    <!--end:::Tab item-->
                </ul>
                <!--end:::Tabs-->
    
                <div class="d-flex justify-content-end my-5" style="margin-top: -60px!important;">
                    <!--begin::Button-->
                    <a  href="{{ route('employees.edit', $employee->id) }}"
                    id="kt_ecommerce_add_product_cancel" class="btn btn-sm btn-primary me-5">Edit Employee</a>
                    <a class="btn btn-sm btn-success" href="{{ route('employees.index') }}"
                    id="kt_ecommerce_add_employee_cancel">Back</a>
                    
                    <!--end::Button-->
                </div>
            </div>
            <!--begin::Content-->
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <!--begin::Content container-->
                <div id="kt_app_content_container" class="app-container">
                    <!--begin::Main column-->
                    <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                        <!-- Content Row -->
                        <div class="card shadow">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12 pb-5 mb-5">
                                        @if ($employee->photo !== null)
                                            <img src="{{ Storage::url($employee->photo) }}" height="150" width="150" alt="Profile Image"/>
                                        @endif
                                        @if ($employee->signature !== null)
                                            <img src="{{ Storage::url($employee->signature) }}" height="80" width="150" alt="Signature" />
                                        @endif
                                    </div>
                                    <div class="col-md-6">
                                        <table class="table table-hover table-bordered">
                                            <tbody>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Company Name:</strong></th>
                                                    <td class="w-50">{{ $employee->branch_name}}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Department Name:</strong></th>
                                                    <td class="w-50">{{ $employee->department_name}}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Designation Name:</strong></th>
                                                    <td class="w-50">{{ $employee->designation_name}}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Joining Date:</strong></th>
                                                    <td class="w-50">{{ $employee->joining_date }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Job Status:</strong></th>
                                                    <td class="w-50">{{ $employee->job_status }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>NID:</strong></th>
                                                    <td class="w-50">{{ $employee->nid }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Emergency Contact Person:</strong></th>
                                                    <td class="w-50">{{ $employee->emergency_contact_person }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Emergency Contact Number:</strong></th>
                                                    <td class="w-50">{{ $employee->emergency_contact_number }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Father Name:</strong></th>
                                                    <td class="w-50">{{ $employee->father_name }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Mother Name:</strong></th>
                                                    <td class="w-50">{{ $employee->mother_name }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Present Address:</strong></th>
                                                    <td class="w-50">{{ $employee->present_address }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Permanent Address:</strong></th>
                                                    <td class="w-50">{{ $employee->permanent_address }}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="col-md-6">
                                        <table class="table table-hover table-bordered">
                                            <tbody>                                        
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Employee Code:</strong></th>
                                                    <td class="w-50">{{ $employee->employee_code }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Employee Name:</strong></th>
                                                    <td class="w-50">{{ $employee->employee_name }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Email Address:</strong></th>
                                                    <td class="w-50">{{ $employee->email }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Mobile Number One:</strong></th>
                                                    <td class="w-50">{{ $employee->mobile }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Mobile Number Two:</strong></th>
                                                    <td class="w-50">{{ $employee->mobile_two }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>DOB:</strong></th>
                                                    <td class="w-50">{{ $employee->dob }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Gender:</strong></th>
                                                    <td class="w-50">{{ $employee->gender }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Blood Group:</strong></th>
                                                    <td class="w-50">{{ $employee->blood_group }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Marital Status:</strong></th>
                                                    <td class="w-50">{{ $employee->marital_status}}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Religion:</strong></th>
                                                    <td class="w-50">{{ $employee->religion }}</td>
                                                </tr>
                                                
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Order:</strong></th>
                                                    <td class="w-50">{{ $employee->order }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Status:</strong></th>
                                                    <td class="w-50">{{ $employee->status==1?'Active':'Disable' }}</td>
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Content Row -->
                    </div>
                    <!--end::Main column-->
                </div>
                <!--end::Content container-->
            </div>
            <!--end::Content-->


            <!--begin::Toolbar-->
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                <!--begin::Toolbar container-->
                <div id="kt_app_toolbar_container" class="app-container d-flex flex-stack">
                    <!--begin::Page title-->
                    <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                        <!--begin::Title-->
                        <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                            Education </h1>
                        <!--end::Title-->
                    </div>
                    <!--end::Page title-->
                </div>
                <!--end::Toolbar container-->
            </div>
            <!--end::Toolbar-->

            <!--begin::Content-->
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <!--begin::Content container-->
                <div id="kt_app_content_container" class="app-container">
                    <!--begin::Main column-->
                    <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                        <!-- Content Row -->
                        <div class="card shadow">
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-md-12">
                                        <table class="table table-hover table-bordered">

                                            <tr>
                                                <th>Exam</th>
                                                <th>Institution</th>
                                                <th>Passingyear</th>
                                                <th>Result</th>
                                            </tr>
                                                @foreach ($employee_educations as $employee_education)
                                            <tr>
                                                <td>{{ $employee_education->exam }}</td>
                                                <td>{{ $employee_education->institution }}</td>
                                                <td>{{ $employee_education->passingyear }}</td>
                                                <td>{{ $employee_education->result }}</td>
                                            </tr>
                                                @endforeach
                                        </table>
                                    </div>


                                </div>

                            </div>
                        </div>

                        <!-- Content Row -->
                    </div>
                    <!--end::Main column-->
                </div>
                <!--end::Content container-->
            </div>
            <!--end::Content-->
            <!--begin::Toolbar-->
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                <!--begin::Toolbar container-->
                <div id="kt_app_toolbar_container" class="app-container d-flex flex-stack">
                    <!--begin::Page title-->
                    <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                        <!--begin::Title-->
                        <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                            Employee Job Histories </h1>
                        <!--end::Title-->
                    </div>
                    <!--end::Page title-->
                </div>
                <!--end::Toolbar container-->
            </div>
            <!--end::Toolbar-->

            <!--begin::Content-->
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <!--begin::Content container-->
                <div id="kt_app_content_container" class="app-container">
                    <!--begin::Main column-->
                    <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                        <!-- Content Row -->
                        <div class="card shadow">
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-md-12">
                                        <table class="table table-hover table-bordered">

                                            <tr>
                                                <th>Company Name</th>
                                                <th>Designation</th>
                                                <th>Start Date</th>
                                                <th>End Date</th>
                                            </tr>
                                                @foreach ($employee__job_histories as $employee__job_historie)
                                            <tr>
                                                <td>{{ $employee__job_historie->company_name }}</td>
                                                <td>{{ $employee__job_historie->designation }}</td>
                                                <td>{{ $employee__job_historie->start_date }}</td>
                                                <td>{{ $employee__job_historie->end_date }}</td>
                                            </tr>
                                                        @endforeach
                                        </table>
                                    </div>


                                </div>

                            </div>
                        </div>
                        {{-- <div class="d-flex justify-content-end">
                            <!--begin::Button-->
                            <a class="btn btn-sm btn-success" href="{{ route('employees.index') }}"
                               id="kt_ecommerce_add_employee_cancel">Back</a>
                            <!--end::Button-->
                        </div> --}}
                        <!-- Content Row -->
                    </div>
                    <!--end::Main column-->
                </div>
                <!--end::Content container-->
            </div>
            <!--end::Content-->

        </div>
        <!--end::Content wrapper-->

    </div>
</x-default-layout>