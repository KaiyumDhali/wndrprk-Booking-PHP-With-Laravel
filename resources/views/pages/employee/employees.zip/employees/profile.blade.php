<x-default-layout>
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
        <!--begin::Content wrapper-->
        <div class="d-flex flex-column flex-column-fluid">
            <!--begin::Toolbar-->
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                <!--begin::Toolbar container-->
                <div id="kt_app_toolbar_container" class="app-container d-flex flex-stack">
                    <!--begin::Page title-->
                    <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                        <!--begin::Title-->
                        <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                            Profile Details
                        </h1>
                    </div>
                    <!--end::Page title-->

                    <!--begin::Page title-->
                    <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                        <!--begin::Title-->
                        <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                            <a class="btn btn-sm btn-primary px-5" href="{{ route('employees.edit', $employee->id) }}">Update Profile</a>
                        </h1>
                        <!--end::Title-->
                    </div>
                    <!--end::Page title-->                    
                </div>
                <!--end::Toolbar container-->
            </div>
            <!--end::Toolbar-->

            <!--begin::Content-->
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <!--begin::Content container-->
                <div id="kt_app_content_container" class="app-container">
                    <!--begin::Main column-->
                    <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                        <!-- Content Row -->
                        <div class="card shadow">
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-md-6">
                                        <table class="table table-hover table-bordered">
                                            <tbody>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Branch Name:</strong></th>
                                                    <td class="w-50">{{ $employee->branch_name }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Department Name:</strong>
                                                    </th>
                                                    <td class="w-50">{{ $employee->department_name }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Designation Name:</strong>
                                                    </th>
                                                    <td class="w-50">{{ $employee->designation_name }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Joining Date:</strong>
                                                    </th>
                                                    <td class="w-50">{{ $employee->joining_date }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Job Status:</strong></th>
                                                    <td class="w-50">{{ $employee->job_status }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Highest
                                                            Education:</strong></th>
                                                    <td class="w-50">{{ $employee->highest_education }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Reference One
                                                            Name:</strong></th>
                                                    <td class="w-50">{{ $employee->reference_one_name }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Reference One
                                                            Phone:</strong></th>
                                                    <td class="w-50">{{ $employee->reference_one_phone }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Reference One
                                                            Address:</strong></th>
                                                    <td class="w-50">{{ $employee->reference_one_address }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Reference Tow
                                                            Name:</strong></th>
                                                    <td class="w-50">{{ $employee->reference_two_name }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Reference Tow
                                                            Phone:</strong></th>
                                                    <td class="w-50">{{ $employee->reference_two_phone }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Reference Tow
                                                            Address:</strong></th>
                                                    <td class="w-50">{{ $employee->reference_two_address }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Present Address:</strong>
                                                    </th>
                                                    <td class="w-50">{{ $employee->present_address }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Permanent
                                                            Address:</strong></th>
                                                    <td class="w-50">{{ $employee->permanent_address }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Employee Image:</strong>
                                                    </th>
                                                    <td class="w-50"><img
                                                            src="{{ Storage::url('images/employees/' . $employee->photo) }}"
                                                            height="180" width="180" alt="" /></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="col-md-6">
                                        <table class="table table-hover table-bordered">
                                            <tbody>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Employee Code:</strong>
                                                    </th>
                                                    <td class="w-50">{{ $employee->employee_code }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Employee Name:</strong>
                                                    </th>
                                                    <td class="w-50">{{ $employee->employee_name }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Mobile Number:</strong>
                                                    </th>
                                                    <td class="w-50">{{ $employee->mobile }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Email Address:</strong>
                                                    </th>
                                                    <td class="w-50">{{ $employee->email }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>DOB:</strong></th>
                                                    <td class="w-50">{{ $employee->dob }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Gender:</strong></th>
                                                    <td class="w-50">{{ $employee->gender == 1 ? 'Male' : 'Female' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Blood Group:</strong></th>
                                                    <td class="w-50">{{ $employee->blood_group }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Marital Status:</strong>
                                                    </th>
                                                    <td class="w-50">
                                                        {{ $employee->marital_status == 1 ? 'Single' : 'Married' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Religion:</strong></th>
                                                    <td class="w-50">{{ $employee->religion }}</td>
                                                </tr>

                                                <tr>
                                                    <th scope="row" class="w-50"><strong>NID:</strong></th>
                                                    <td class="w-50">{{ $employee->nid }}</td>
                                                </tr>
                                                {{-- <tr>
                                                    <th scope="row" class="w-50"><strong>Salary:</strong></th>
                                                    <td class="w-50">{{ $employee->salary }}</td>
                                                </tr> --}}
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Emergency Contact
                                                            Person:</strong></th>
                                                    <td class="w-50">{{ $employee->emergency_contact_person }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Emergency Contact
                                                            Number:</strong></th>
                                                    <td class="w-50">{{ $employee->emergency_contact_number }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Father Name:</strong></th>
                                                    <td class="w-50">{{ $employee->father_name }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Mother Name:</strong></th>
                                                    <td class="w-50">{{ $employee->mother_name }}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row" class="w-50"><strong>Signature:</strong></th>
                                                    <td class="w-50"><img
                                                            src="{{ Storage::url('images/employees/' . $employee->signature) }}"
                                                            height="180" width="180" alt="" /></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Content Row -->
                    </div>
                    <!--end::Main column-->
                </div>
                <!--end::Content container-->
            </div>
            <!--end::Content-->


            <!--begin::Toolbar-->
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                <!--begin::Toolbar container-->
                <div id="kt_app_toolbar_container" class="app-container d-flex flex-stack">
                    <!--begin::Page title-->
                    <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                        <!--begin::Title-->
                        <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                            Education </h1>
                        <!--end::Title-->
                    </div>
                    <!--end::Page title-->
                </div>
                <!--end::Toolbar container-->
            </div>
            <!--end::Toolbar-->

            <!--begin::Content-->
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <!--begin::Content container-->
                <div id="kt_app_content_container" class="app-container">
                    <!--begin::Main column-->
                    <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                        <!-- Content Row -->
                        <div class="card shadow">
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-md-12">
                                        <table class="table table-hover table-bordered">

                                            <tr>
                                                <th>Exam</th>
                                                <th>Institution</th>
                                                <th>Passingyear</th>
                                                <th>Result</th>
                                            </tr>
                                            @foreach ($employee_educations as $employee_education)
                                                <tr>
                                                    <td>{{ $employee_education->exam }}</td>
                                                    <td>{{ $employee_education->institution }}</td>
                                                    <td>{{ $employee_education->passingyear }}</td>
                                                    <td>{{ $employee_education->result }}</td>
                                                </tr>
                                            @endforeach
                                        </table>
                                    </div>


                                </div>

                            </div>
                        </div>

                        <!-- Content Row -->
                    </div>
                    <!--end::Main column-->
                </div>
                <!--end::Content container-->
            </div>
            <!--end::Content-->
            <!--begin::Toolbar-->
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                <!--begin::Toolbar container-->
                <div id="kt_app_toolbar_container" class="app-container d-flex flex-stack">
                    <!--begin::Page title-->
                    <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                        <!--begin::Title-->
                        <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                            Employee Job Histories </h1>
                        <!--end::Title-->
                    </div>
                    <!--end::Page title-->
                </div>
                <!--end::Toolbar container-->
            </div>
            <!--end::Toolbar-->

            <!--begin::Content-->
            <div id="kt_app_content" class="app-content flex-column-fluid">
                <!--begin::Content container-->
                <div id="kt_app_content_container" class="app-container">
                    <!--begin::Main column-->
                    <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                        <!-- Content Row -->
                        <div class="card shadow">
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-md-12">
                                        <table class="table table-hover table-bordered">
                                            <tr>
                                                <th>Company Name</th>
                                                <th>Designation</th>
                                                <th>Start Date</th>
                                                <th>End Date</th>
                                            </tr>
                                            @foreach ($employee_job_histories as $employee_job_historie)
                                                <tr>
                                                    <td>{{ $employee_job_historie->company_name }}</td>
                                                    <td>{{ $employee_job_historie->designation }}</td>
                                                    <td>{{ $employee_job_historie->start_date }}</td>
                                                    <td>{{ $employee_job_historie->end_date }}</td>
                                                </tr>
                                            @endforeach
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Content Row -->
                    </div>
                    <!--end::Main column-->
                </div>
                <!--end::Content container-->
            </div>
            <!--end::Content-->
        </div>
        <!--end::Content wrapper-->
    </div>
</x-default-layout>
